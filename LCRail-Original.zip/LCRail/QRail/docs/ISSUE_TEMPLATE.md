1. **What happens**: 
    - What's actually happening
    
2. **What was expected**:
    - What's expected to happen

3. **How to reproduce**: 
    1. Steps

4. **Environment**: 
    - Sailfish OS version:
    - Sailfish OS hardware: 
