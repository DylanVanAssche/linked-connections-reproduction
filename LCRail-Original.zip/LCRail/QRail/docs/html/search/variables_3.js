var searchData=
[
  ['name',['name',['../logger_8h.html#abc29e461e01cc0c712944f8f47f91331',1,'logger.h']]]
];
