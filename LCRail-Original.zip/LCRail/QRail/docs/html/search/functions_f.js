var searchData=
[
  ['release',['release',['../classOS.html#a1d00cd418f5d83cc174492326f7cd604',1,'OS']]],
  ['releasechanged',['releaseChanged',['../classOS.html#a58369b88b24b1701b020bd0971d99c03',1,'OS']]],
  ['remarks',['remarks',['../classRouterEngine_1_1Route.html#a003a75085fca704ade0509ccc09ce0e6',1,'RouterEngine::Route']]],
  ['remarkschanged',['remarksChanged',['../classRouterEngine_1_1Route.html#a42ba6dd381b51f8c9fb31bfd18386674',1,'RouterEngine::Route']]],
  ['requestcompleted',['requestCompleted',['../classNetwork_1_1Manager.html#a1863c9a52ea6587387c8a688b92a2204',1,'Network::Manager']]],
  ['route',['Route',['../classRouterEngine_1_1Route.html#af55797a1f0895e2c361aa48c7b17a83c',1,'RouterEngine::Route::Route(const QList&lt; RouterEngine::RouteLeg *&gt; &amp;legs, const QList&lt; RouterEngine::Transfer *&gt; &amp;transfers, const QList&lt; AlertsEngine::Message *&gt; &amp;tripAlerts, const QList&lt; AlertsEngine::Message *&gt; &amp;vehicleAlerts, const QList&lt; AlertsEngine::Message *&gt; &amp;remarks, QObject *parent=nullptr)'],['../classRouterEngine_1_1Route.html#a4b2d697502c5de4298cb8f6cfc14e22c',1,'RouterEngine::Route::Route(const QList&lt; RouteLeg *&gt; &amp;legs, QObject *parent=nullptr)']]],
  ['routeleg',['RouteLeg',['../classRouterEngine_1_1RouteLeg.html#a1c2b7ecc87cab7b5a4ff69d07f4e646a',1,'RouterEngine::RouteLeg']]],
  ['routelegend',['RouteLegEnd',['../classRouterEngine_1_1RouteLegEnd.html#ac8d5c3ffe9d65a83cae8c7de5962e818',1,'RouterEngine::RouteLegEnd']]],
  ['routes',['routes',['../classRouterEngine_1_1Planner.html#a5fc863694446aa45cb56bb3c3ab4c5b4',1,'RouterEngine::Planner']]],
  ['routesfound',['routesFound',['../classRouterEngine_1_1Planner.html#a5c655efeb575e8842cf20bdd16fc025e',1,'RouterEngine::Planner']]],
  ['routeuri',['routeURI',['../classFragments_1_1Fragment.html#a58ca3c71db8995b1a60b1eee17d65911',1,'Fragments::Fragment']]],
  ['routeurichanged',['routeURIChanged',['../classFragments_1_1Fragment.html#ab220e9fef71bf161e14769afc61f0499',1,'Fragments::Fragment']]]
];
