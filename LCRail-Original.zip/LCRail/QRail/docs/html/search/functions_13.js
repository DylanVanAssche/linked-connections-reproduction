var searchData=
[
  ['validatedata',['validateData',['../classVehicleEngine_1_1Factory.html#a2e2e49cee65a409309492354de57b496',1,'VehicleEngine::Factory::validateData()'],['../classFragments_1_1Factory.html#a62a60fd81fec95b794a8b27188b51824',1,'Fragments::Factory::validateData()']]],
  ['vehicle',['Vehicle',['../classVehicleEngine_1_1Vehicle.html#a208c46e84099d0f24ebcf699aedf9ca2',1,'VehicleEngine::Vehicle::Vehicle(QObject *parent=nullptr)'],['../classVehicleEngine_1_1Vehicle.html#a637a49b74131270fdf0d73a6268e2716',1,'VehicleEngine::Vehicle::Vehicle(const QUrl &amp;uri, const QUrl &amp;tripURI, const QString &amp;headsign, QObject *parent=nullptr)'],['../classVehicleEngine_1_1Vehicle.html#ac3b5f107da52e20512f9fca88a9ef3b3',1,'VehicleEngine::Vehicle::Vehicle(const QUrl &amp;uri, const QUrl &amp;tripURI, const QString &amp;headsign, const QList&lt; VehicleEngine::Stop *&gt; &amp;intermediaryStops, QObject *parent=nullptr)']]],
  ['vehiclealerts',['vehicleAlerts',['../classRouterEngine_1_1Route.html#a2d3c6fd345bd099e769ad06896199bc6',1,'RouterEngine::Route']]],
  ['vehiclealertschanged',['vehicleAlertsChanged',['../classRouterEngine_1_1Route.html#a1ea5875ee80dca0f253caee323f23410',1,'RouterEngine::Route']]],
  ['vehicleinformation',['vehicleInformation',['../classRouterEngine_1_1RouteLeg.html#a086d61b828cd572797ec327710eb4088',1,'RouterEngine::RouteLeg']]],
  ['vehicleinformationchanged',['vehicleInformationChanged',['../classRouterEngine_1_1RouteLeg.html#a11952e3a2fee4fa1d9f4fb56e69f0507',1,'RouterEngine::RouteLeg']]],
  ['vehicleready',['vehicleReady',['../classVehicleEngine_1_1Factory.html#af23bdc01d77eb6c9feb7f79f00511c22',1,'VehicleEngine::Factory']]],
  ['version',['version',['../classOS.html#a4cd043becb244d8f40bdcc55c0417a71',1,'OS']]],
  ['versionchanged',['versionChanged',['../classOS.html#a2bb282eb19c9eaa0c787dabc434a9fca',1,'OS']]],
  ['videolocation',['videoLocation',['../classOS.html#afdfd88fe0b70d4ed51508e7dc364b1d4',1,'OS']]]
];
