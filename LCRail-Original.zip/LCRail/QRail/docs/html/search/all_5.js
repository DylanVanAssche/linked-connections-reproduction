var searchData=
[
  ['manager',['Manager',['../classNetwork_1_1Manager.html',1,'Network::Manager'],['../classDatabase_1_1Manager.html',1,'Database::Manager']]],
  ['message',['Message',['../classAlertsEngine_1_1Message.html',1,'AlertsEngine']]]
];
