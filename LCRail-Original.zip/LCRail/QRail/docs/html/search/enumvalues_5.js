var searchData=
[
  ['invalid',['INVALID',['../classRouterEngine_1_1Transfer.html#a2b79055b3dc55c7d9631a0d3e68155c5accc0377a8afbf50e7094f5c23a8af223',1,'RouterEngine::Transfer']]]
];
