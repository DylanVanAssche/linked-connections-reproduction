var searchData=
[
  ['database',['Database',['../namespaceDatabase.html',1,'']]],
  ['databasemanager_2ecpp',['databasemanager.cpp',['../databasemanager_8cpp.html',1,'']]]
];
