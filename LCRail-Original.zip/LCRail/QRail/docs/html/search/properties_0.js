var searchData=
[
  ['appname',['appName',['../classOS.html#af9d6295c5361884c9c7c25b13db70720',1,'OS']]],
  ['appnamepretty',['appNamePretty',['../classOS.html#a5ecf65ef8f4ac491323d1590c2cb4e67',1,'OS']]],
  ['appversion',['appVersion',['../classOS.html#a8162949b8a268b409967ae356947e059',1,'OS']]]
];
