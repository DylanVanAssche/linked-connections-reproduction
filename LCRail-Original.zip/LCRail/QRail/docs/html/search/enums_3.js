var searchData=
[
  ['type',['Type',['../classRouterEngine_1_1RouteLeg.html#acdcc25212c113c641ee3fbaebb52a7bd',1,'RouterEngine::RouteLeg::Type()'],['../classRouterEngine_1_1Transfer.html#a2b79055b3dc55c7d9631a0d3e68155c5',1,'RouterEngine::Transfer::Type()'],['../classVehicleEngine_1_1Stop.html#ae0c7ddc417639975e00b58181c3ee458',1,'VehicleEngine::Stop::Type()']]]
];
