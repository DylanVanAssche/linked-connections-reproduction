var searchData=
[
  ['unknown',['UNKNOWN',['../classVehicleEngine_1_1Stop.html#ae0c7ddc417639975e00b58181c3ee458a696b031073e74bf2cb98e5ef201d4aa3',1,'VehicleEngine::Stop::UNKNOWN()'],['../classVehicleEngine_1_1Stop.html#acdfae8b416558c41043261aaa02fdfe6a696b031073e74bf2cb98e5ef201d4aa3',1,'VehicleEngine::Stop::UNKNOWN()']]],
  ['unsupported',['UNSUPPORTED',['../classVehicleEngine_1_1Stop.html#acdfae8b416558c41043261aaa02fdfe6a40aa75f8e8cfdf7b660c5620e953229f',1,'VehicleEngine::Stop']]]
];
