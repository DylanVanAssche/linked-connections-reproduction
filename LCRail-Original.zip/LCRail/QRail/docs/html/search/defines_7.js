var searchData=
[
  ['transfer_5fequivalent_5ftravel_5ftime',['TRANSFER_EQUIVALENT_TRAVEL_TIME',['../routerplanner_8h.html#a787017c6118cb210d90bc7709b09b7d4',1,'routerplanner.h']]]
];
