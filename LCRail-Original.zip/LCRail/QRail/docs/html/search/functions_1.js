var searchData=
[
  ['board',['Board',['../classLiveboardEngine_1_1Board.html#a70370a5f86db87e9edb9ca23de58b38b',1,'LiveboardEngine::Board::Board(QObject *parent=nullptr)'],['../classLiveboardEngine_1_1Board.html#ae1f97006ef5590a3b4c6b27f48c83c1f',1,'LiveboardEngine::Board::Board(const QList&lt; VehicleEngine::Vehicle *&gt; &amp;entries, StationEngine::Station *station, const QDateTime &amp;from, const QDateTime &amp;until, QObject *parent=nullptr)']]]
];
