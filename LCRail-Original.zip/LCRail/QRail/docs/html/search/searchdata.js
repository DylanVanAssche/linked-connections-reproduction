var indexSectionsWithContent =
{
  0: "abdflmnopqrstv",
  1: "bfmnoprstv",
  2: "adflnrsv",
  3: "adflnqrsv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files"
};

