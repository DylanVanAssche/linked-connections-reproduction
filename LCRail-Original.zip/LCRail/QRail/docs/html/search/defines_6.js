var searchData=
[
  ['seconds_5fto_5fhours_5fmultiplier',['SECONDS_TO_HOURS_MULTIPLIER',['../liveboardfactory_8h.html#a99e430ba4788dc5ce8b767a6a55f9ce6',1,'SECONDS_TO_HOURS_MULTIPLIER():&#160;liveboardfactory.h'],['../routerplanner_8h.html#a99e430ba4788dc5ce8b767a6a55f9ce6',1,'SECONDS_TO_HOURS_MULTIPLIER():&#160;routerplanner.h']]]
];
