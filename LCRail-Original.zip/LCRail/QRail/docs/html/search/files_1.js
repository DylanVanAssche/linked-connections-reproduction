var searchData=
[
  ['databasemanager_2ecpp',['databasemanager.cpp',['../databasemanager_8cpp.html',1,'']]]
];
