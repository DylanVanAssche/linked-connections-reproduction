var searchData=
[
  ['line_5flength',['LINE_LENGTH',['../logger_8h.html#ad5131de0b5004c64db5e79e8aac7471e',1,'logger.h']]]
];
