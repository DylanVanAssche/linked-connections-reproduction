var searchData=
[
  ['devicepixelratio',['devicepixelratio',['../classOS.html#aa40d035f4f4b1f67c6c103cd3b3cfc08',1,'OS']]]
];
