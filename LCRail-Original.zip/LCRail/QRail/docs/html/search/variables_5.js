var searchData=
[
  ['version',['version',['../logger_8h.html#accb344ff518c8d35f4e2a0df6fe3a6d1',1,'logger.h']]]
];
