var searchData=
[
  ['base_5furl',['BASE_URL',['../fragmentsfactory_8h.html#acbb11c1e34784cf1e3147029f942bfd6',1,'fragmentsfactory.h']]]
];
