1. **Explanation**: 
    - Explain here

2. **Fixed issues**: 
    - Fixed #

3. **Testing environment**: 
    - Sailfish OS version: 
    - Sailfish OS hardware: 
